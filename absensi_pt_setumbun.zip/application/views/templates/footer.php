<div class="footer">
    <div align="center">
        <strong>Copyright</strong> PT Delta Indratama Orion &copy; 2021
    </div>
</div>

</div>
</div>

</body>

</html>