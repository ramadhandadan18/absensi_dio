<!DOCTYPE html>
<html>

<head>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>PT DIO</title>

	<link href="<?php echo base_url() ?>assets/images/favicon-16x16.png" rel="shortcut icon">

	<link href="<?php echo base_url() ?>assets/css/bootstrap.min.css" rel="stylesheet">
	<link href="<?php echo base_url() ?>assets/font-awesome/css/font-awesome.css" rel="stylesheet">

	<link href="<?php echo base_url() ?>assets/css/plugins/dataTables/datatables.min.css" rel="stylesheet">

	<link href="<?php echo base_url() ?>assets/css/animate.css" rel="stylesheet">
	<link href="<?php echo base_url() ?>assets/css/style.css" rel="stylesheet">
	<link href="<?php echo base_url() ?>assets/css/plugins/toastr/toastr.min.css" rel="stylesheet">

	<link href="<?php echo base_url() ?>assets/css/plugins/awesome-bootstrap-checkbox/awesome-bootstrap-checkbox.css" rel="stylesheet">
	<link href="<?php echo base_url() ?>assets/css/plugins/iCheck/custom.css" rel="stylesheet">
	<style type="text/css">
		#dua,
		#tiga {
			position: absolute;
			height: 200px;
		}

		#dua {
			width: 100%;
			background-color: #1494C6;
			z-index: 2;
		}

		#tiga {
			width: 100%;
			top: 50px;
			z-index: 3;
			display: block;
			margin-left: auto;
			margin-right: auto;
		}
	</style>
</head>

<body style="background-color: white;">