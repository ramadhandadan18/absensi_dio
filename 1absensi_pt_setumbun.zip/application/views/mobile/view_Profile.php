	<nav class="navbar fixed-top navbar-light" style="background-color:#1494C6;color:white;">
		<a class="navbar-brand" href="#" style="color: white;">Profile</a>
	</nav>

	<div style="overflow-y: scroll;padding-top: 70px;padding-bottom: 100px;">
		<div class="container">
			<div class="row" style="padding-bottom: 40px;">
				<div class="card" style="width: 90%;padding-bottom: 20px;border-radius: 12px;display: block;margin-left: auto;margin-right: auto;">
					<div class="card-body">
						<div class="container">
							<div class="row">
								<div class="col-12">
									<b>
										<p style='color: black;'>Personal Information</p>
									</b>
								</div>
							</div>
							<div class="row">
								<div class="col-12">
									<b>
										<p class="mb-0" style="text-align: left;color: black;">NIP</p>
									</b>
									<p class="mb-0" style="text-align: left;"><?php echo $my_nip; ?></p>
									<hr>
								</div>
								<div class="col-12">
									<b>
										<p class="mb-0" style="text-align: left;color: black;">Name</p>
									</b>
									<p class="mb-0" style="text-align: left;"><?php echo $my_name; ?></p>
									<hr>
								</div>
								<div class="col-12">
									<b>
										<p class="mb-0" style="text-align: left;color: black;">Email ID</p>
									</b>
									<p class="mb-0" style="text-align: left;"><?php echo $my_email; ?></p>
									<hr>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="container">
			<div class="row">
				<div class="card" style="width: 90%;padding-bottom: 20px;border-radius: 12px;display: block;margin-left: auto;margin-right: auto;">
					<div class="card-body">
						<div class="container">
							<div class="row">
								<div class="col-12">
									<b>
										<p style='color: black;'>Other Information</p>
									</b>
								</div>
							</div>
							<div class="row">
								<div class="col-12">
									<a href="<?php echo base_url() ?>Logout/" style='color: black;'><i class="fa fa-sign-out"></i> <span class="nav-label">&nbsp;Logout</span></a>
									<!-- <button type="button" class="btn btn-danger" href="<?php echo base_url() ?>Logout/" style='color: white;'><i class="fa fa-sign-out"></i> <span class="nav-label">&nbsp;Logout</span></button> -->
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>


	<!-- Mainly scripts -->
	<script src="<?php echo base_url() ?>assets/js/jquery-3.1.1.min.js"></script>
	<script src="<?php echo base_url() ?>assets/js/popper.min.js"></script>
	<script src="<?php echo base_url() ?>assets/js/bootstrap.js"></script>
	<script src="<?php echo base_url() ?>assets/js/plugins/metisMenu/jquery.metisMenu.js"></script>
	<script src="<?php echo base_url() ?>assets/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>
	<script src="<?php echo base_url() ?>assets/js/plugins/toastr/toastr.min.js"></script>

	<!-- Custom and plugin javascript -->
	<script src="<?php echo base_url() ?>assets/js/inspinia.js"></script>
	<script src="<?php echo base_url() ?>assets/js/plugins/pace/pace.min.js"></script>

	<script src="<?php echo base_url() ?>assets/js/plugins/dataTables/datatables.min.js"></script>
	<script src="<?php echo base_url() ?>assets/js/plugins/dataTables/dataTables.bootstrap4.min.js"></script>

	<!-- Page-Level Scripts -->